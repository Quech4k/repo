﻿
namespace Projekt
{
    internal class Uslugi
    {
        // Wybor uslugi
        public string serviceChoose(string packet)
        {
            switch (packet)
            {
                case "Pakiet 1":
                    return "Pakiet 1 - Osuszanie pojazdu.";
                case "Pakiet 2":
                    return "Pakiet 2 - Mycie szczotką.";
                case "Pakiet 3":
                    return "Pakiet 3 - Mycie szczotką + pianą.";
                case "Pakiet 4":
                    return "Pakiet 4 - Mycie Szczotką, pianą + nabłyszczacz.";
                case "Pakiet 5":
                    return "Pakiet 5 - Mycie Szczotką, pianą, nabłyszczacz oraz osuszanie";
            }
            return "Nie posiadamy takiej usługi!";
        }
        //wybor godziny
        public string hourChoose(string hour)
        {
            switch (hour)
            {
                case "12":
                    case "12:00":
                        return "12:00";
                case "13":
                    case "13:00":
                        return "13:00";
                case "14":
                    case "14:00":
                        return "14:00";
                case "15":
                    case "15:00":
                        return "15:00";
                case "16":
                    case "16:00":
                        return "16:00";
                case "17":
                    case "17:00":
                        return "17:00";
                case "18":
                    case "18:00":
                        return "18:00";
            }
            return "Godzina niedostępna";
        }
        // Wybor dnia tygodnia
        public string dayChoose(string day)
        {
            switch (day)
            {
                case "Poniedziałek":
                    case "Poniedzialek":
                case "Pon":
                    return "Poniedzialek";
                case "Wtorek":
                case "Wt":
                    return "Wtorek";
                case "Środa":
                case "Śr":
                case "Sr":
                    return "Środa";
                case "Czwartek":
                case "Czw":
                    return "Czwartek";
                case "Piątek":
                case "Piatek":
                case "Pt":
                    return "Piątek";
                case "Sobota":
                case "Sob":
                    return "Sobota";
                case "Niedziela":
                case "Niedz":
                case "Nd":
                    return "Niedziela";
            }
            return "Nie ma takiego dnia - sprawdz pisownię";
        }
    }
}
