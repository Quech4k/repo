﻿using System;

namespace Projekt
{ internal class Rejestracja
    {
        public void appointment()
        {
            //Informacje klient
            Klient klient = new Klient();
            Console.Write("Podaj swoje imię ");
            klient.name = Console.ReadLine();
            Console.Write("Podaj swoje nazwisko ");
            klient.surname = Console.ReadLine();
            Console.Write("Podaj nazwę swego pojazdu "); 
            klient.carmodel = Console.ReadLine();
            Console.Clear();
            Console.WriteLine("Jakiej usługi potrzebujesz? ");
            Console.WriteLine("Wybierz sposród wymienionych poniżej. ");
            Console.WriteLine("W celu wybrania - wpisz nazwę pakietu np: Pakiet 1 ");

            // Informacje usługi
            Uslugi Uslugi = new Uslugi();
            Console.WriteLine("Dostępne usługi:");
            Console.WriteLine("Pakiet 1 - Osuszanie pojazdu");
            Console.WriteLine("Pakiet 2 - Mycie szczotką");
            Console.WriteLine("Pakiet 3 - Mycie szczotką oraz pianowanie");
            Console.WriteLine("Pakiet 4 - Mycie Szczotką, pianowanie + nabłyszczacz");
            Console.WriteLine("Pakiet 5 - Mycie Szczotką, pianowanie, nabłyszczacz oraz osuszanie");
            string service = Console.ReadLine();
            string choosenService = Uslugi.serviceChoose(service);
            Console.WriteLine("Wybrałeś opcję: " + choosenService);
            Console.Clear();

            // Wybor dnia tygodnia
            Console.WriteLine("Proszę wybrać dogodny dzień tygodnia. Dostępne dni: ");
            Console.WriteLine("Poniedziałek");
            Console.WriteLine("Wtorek");
            Console.WriteLine("Środa");
            Console.WriteLine("Czwartek");
            Console.WriteLine("Piątek");
            Console.WriteLine("Sobota");
            Console.WriteLine("Niedziela");
            string day = (Console.ReadLine());
            string dayChoose = Uslugi.dayChoose(day);
            Console.Clear();

            // Wybor godziny
            Console.WriteLine("Proszę wybrać odpowiednią godzinę, wpisując ją poniżej. ");
            Console.WriteLine("12:00");
            Console.WriteLine("13:00");
            Console.WriteLine("14:00");
            Console.WriteLine("15:00");
            Console.WriteLine("16:00");
            Console.WriteLine("17:00");
            Console.WriteLine("18:00");
            string hour = (Console.ReadLine());
            string hourChoose = Uslugi.hourChoose(hour);
            Console.Clear();

            // Pokaz zebrane info
            Console.WriteLine("---------------------------------------------------------------");
            Console.WriteLine("Imie: " + klient.name);
            Console.WriteLine("Nazwisko: " + klient.surname);
            Console.WriteLine("Pojazd: " + klient.carmodel);
            Console.WriteLine("Godzina: " + hourChoose); 
            Console.WriteLine("Dzień: " + dayChoose);
            Console.WriteLine("Usługa numer: " + choosenService);
            Console.WriteLine("---------------------------------------------------------------");
            Console.WriteLine("Zapraszamy! W razie pytań skontaktuj się z nami pod numerem telefonu: 600 100 100");
            Console.ReadKey();
        }
    }
}
