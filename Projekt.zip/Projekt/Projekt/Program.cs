﻿
namespace Projekt
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Rejestracja rejestracja = new Rejestracja();
            rejestracja.appointment();

        }
    }
}