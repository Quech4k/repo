﻿
namespace Projekt
{
    internal class Klient
    {
        public string name { get; set; }
        public string surname { get; set; } 
        public string carmodel { get; set; }


    }
}